#P103101t
def echo():
    while True:
        inp = int(input("adjon meg egy számot: "))
        if inp > 100 or inp < -100:
            print("RIP bozo")
            break
        else:
            print(inp)
echo()