#P103103e

def absolute_value():
    inp= int(input("TACTICAL NUKE INCOMING!!!!: "))
    if inp < 0:
        print(-inp)
    else:
        print(inp)
absolute_value()