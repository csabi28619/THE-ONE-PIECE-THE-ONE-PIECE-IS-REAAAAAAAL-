#P102109

n = int(input("Adjon meg egy számot ahány számot kíván átlagolni: "))
maxi = max

maxi = 0
for i in range(n):
    f = int(input("Adj meg egy számot: "))
    if f > maxi:
        maxi = f

print(maxi)