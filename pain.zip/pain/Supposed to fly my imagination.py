#P102106

list = []
while True:
    szam = input("Adjon meg számokat, írd be EOF hogy vége legyen: ")
    if int(szam) == 0:
       break
    list.append(int(szam))


sum = 0
for i in list:
     sum = sum + i

print(round(sum/len(list), 2))