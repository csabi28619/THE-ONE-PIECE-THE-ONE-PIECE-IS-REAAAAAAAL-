#P103101e
def echo():
    inp = int(input("adjon meg egy számot: "))

    print(inp)
echo()