#P102105
lista = []
while True:
   szam = input("Írj be számokat, írd be EOF ha vége legyen: ")
   if szam == "EOF":
       break
   lista.append(int(szam))


sum = 0
for i in lista:
   sum = sum + i

print(round(sum/len(list), 2))
