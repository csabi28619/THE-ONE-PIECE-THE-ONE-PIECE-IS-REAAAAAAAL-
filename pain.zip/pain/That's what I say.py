#P102110

list = []
while True:
   f = input("írjon be számokat, írd be EOF, hogy vége legyen vége: ")
   if f == "EOF":
       break
   list.append(int(f))

print(max(list))