#P103103t
def absolute_value():
    while True:
        inp = int(input("adjon meg egy számot: "))
        if inp > 100 or inp < -100:
            break
        elif inp < 0:
            print(-inp)
        else:
            print(inp)
absolute_value()