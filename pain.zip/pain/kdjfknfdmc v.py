#P103103n
def absolute_value():
     
    n = int(input("donk: "))

    for i in range(n):
        inp= int(input("TACTICAL NUKE INCOMING!!!!: "))
        if inp < 0:
            print(-inp)
        else:
            print(inp)
absolute_value()