#P102115
while True:
    f = input("írjon be egy pontszámot 0 és 100 között: ")
    if int(f) > 100 or int(f) < 0:
        break
    if f == "EOF":
       break
    if int(f) >= 80:
        print("jeles")
    elif 80 > int(f) > 70:
        print("jo")
    elif 70> int(f) > 60:
        print("kozepes")
    elif 60 > int(f) > 50:
        print("elegseges")
    elif 50 > int(f):
        print("elegtelen") 