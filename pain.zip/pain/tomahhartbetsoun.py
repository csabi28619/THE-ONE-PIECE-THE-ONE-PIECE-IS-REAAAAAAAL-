#P103101t
def change_signature():
    while True:
        inp = int(input("adjon meg egy számot: "))
        if inp > 100 or inp < -100:
            print("RIP bozo")
            break
        else:
            print(-inp)
change_signature()