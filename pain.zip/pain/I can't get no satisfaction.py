#P102111

KO = input("Adjon meg Két Számot Elválasztva szóközzel: ")

szam1 = int(KO.split(" ")[0])
szam2 = int(KO.split(" ")[1])

while szam2 != 0:
   szam1, szam2 = szam2, szam1 % szam2
print("A két szám legnagyobb közös osztója:", szam1)