#P102108

list = []
while True:
   szam = input("Adj számokat, írd be EOF ha vége: ")
   if szam == "EOF":
       break
   list.append(int(szam))

print(min(list))