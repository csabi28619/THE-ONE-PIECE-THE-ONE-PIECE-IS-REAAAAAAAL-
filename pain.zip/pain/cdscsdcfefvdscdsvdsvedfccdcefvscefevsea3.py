#P102116

while True:
    f = int(input("írjon be egy pontszámot 0 és 100 között: "))
    if f > 100 or f < 0:
        break
    if f >= 80:
        print("jeles")
    elif 80 > f > 70:
        print("jo")
    elif 70> f > 60:
        print("kozepes")
    elif 60 > f > 50:
        print("elegseges")
    elif 50 > f:
        print("elegtelen") 