#P102107

n = int(input("Adjon meg egy számot ahány számot kíván átlagolni: "))
mini = float('inf')

for i in range(n):
    f = int(input("Adj meg egy számot: "))
    if f <mini:
        mini = f

print(mini)