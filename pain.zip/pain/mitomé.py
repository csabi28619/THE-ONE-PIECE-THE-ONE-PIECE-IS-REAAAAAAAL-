#P102113

num = int(input("Adjon Egy Számot: "))

prim = False

if num == 1:
    print("NEM")
elif num > 1:
    for i in range(2, num):
        if (num % i) == 0:
            prim = True
            break
    if prim:
        print("NEM")
    else:
        print("IGEN")