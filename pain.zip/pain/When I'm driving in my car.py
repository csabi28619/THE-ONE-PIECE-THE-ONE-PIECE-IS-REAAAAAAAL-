#P102101

a = int(input("írjon be egy egész számot: ")) 
j = input("egy művelet jelet: ") 
b = int(input("egy egész számot: "))

if (j=="+"):
    print(a + b),
elif(j=="-"):
    print(a - b),
elif(j=="/"):
    print(a / b),
elif(j=="%"):
    print(a % b),
elif(j=="//"):
    print(a // b),
elif(j=="*"):
    print(a * b)

