#P103102e

def change_signature():
    inp = int(input("szam most!: "))

    print(-inp)
change_signature()