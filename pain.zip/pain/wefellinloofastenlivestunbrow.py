#P103102n
def change_signature():
    n = int(input("adjon meg egy számot: "))

    for i in range(n):
        inp = int(input("szám ok: "))
        print(-inp)
change_signature()