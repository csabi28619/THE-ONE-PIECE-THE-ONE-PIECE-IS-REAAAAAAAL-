#P102104
n = int(input("Adjon meg egy számot ahány számot kíván átlagolni: "))
list = []

for i in range(n):
    f = int(input("Adj meg egy számot: "))
    list.append(f)

sum = 0
for i in list:
   sum = sum + i

print(round(sum/n, 2))
