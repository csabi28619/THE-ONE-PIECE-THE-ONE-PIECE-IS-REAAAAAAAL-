#P102103

a = int(input("írjon be egy egész számot: ")) 
if a == 0:
    print("a szám nem lehet 0")
else:
    j = input("egy művelet jelet: ") 
    b = int(input("egy egész számot: "))
if b == 0:
    print("a szám nem lehet 0")
else:



    if (j=="+"):
        print(a + b),
    elif(j=="-"):
        print(a - b),
    elif(j=="/"):
        print(a / b),
    elif(j=="%"):
        print(a % b),
    elif(j=="//"):
        print(a // b),
    elif(j=="*"):
        print(a * b)

    