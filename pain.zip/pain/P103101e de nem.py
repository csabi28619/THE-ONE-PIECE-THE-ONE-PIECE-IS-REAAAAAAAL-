#P103101n

def echo():
    n = int(input("adjon meg egy számot: "))

    for i in range(n):
        inp = int(input("szám ok: "))
        print(inp)
echo() 